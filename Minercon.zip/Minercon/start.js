const app=require('express')();

app.get('/',(req, res)=>{
    res.sendFile(__dirname+'/home.html');
});
app.get('/home.html',(req, res)=>{
    res.sendFile(__dirname+'/home.html');
});
app.get('/try.html',(req, res)=>{
    res.sendFile(__dirname+'/try.html');
});
app.get('/poxer.js',(req, res)=>{
    res.sendFile(__dirname+'/poxer.js');
});
app.get('/shop.html',(req, res)=>{
    res.sendFile(__dirname+'/shop.html');
});
app.get('/cursor.js',(req, res)=>{
    res.sendFile(__dirname+'/cursor.js');
});
app.get('/game.js',(req, res)=>{
    res.sendFile(__dirname+'/game.js');
});
app.get('/static/home_logo.png',(req, res)=>{
    res.sendFile(__dirname+'/static/home_logo.png');
});
app.get('/static/home.jpg',(req, res)=>{
    res.sendFile(__dirname+'/static/home.jpg');
});
app.get('/static/play.png',(req, res)=>{
    res.sendFile(__dirname+'/static/play.png');
});
app.get('/static/shop_logo.png',(req, res)=>{
    res.sendFile(__dirname+'/static/shop_logo.png');
});
app.get('/static/shop.png',(req, res)=>{
    res.sendFile(__dirname+'/static/shop.png');
});
app.get('/pickaxe/wooden.png',(req, res)=>{
    res.sendFile(__dirname+'/pickaxe/wooden.png');
});
app.get('/pickaxe/stone.png',(req, res)=>{
    res.sendFile(__dirname+'/pickaxe/stone.png');
});
app.get('/pickaxe/iron.png',(req, res)=>{
    res.sendFile(__dirname+'/pickaxe/iron.png');
});
app.get('/pickaxe/diamond.png',(req, res)=>{
    res.sendFile(__dirname+'/pickaxe/diamond.png');
});
app.get('/pickaxe/netherite.png',(req, res)=>{
    res.sendFile(__dirname+'/pickaxe/netherite.png');
});
app.get('/item/cobblestone.png',(req, res)=>{
    res.sendFile(__dirname+'/item/cobblestone.png');
});
app.get('/item/diamond.png',(req, res)=>{
    res.sendFile(__dirname+'/item/diamond.png');
});
app.get('/item/lapis.png',(req, res)=>{
    res.sendFile(__dirname+'/item/lapis.png');
});
app.get('/item/emerald.png',(req, res)=>{
    res.sendFile(__dirname+'/item/emerald.png');
});
app.get('/item/iron.png',(req, res)=>{
    res.sendFile(__dirname+'/item/iron.png');
});
app.get('/item/cursor.gif',(req, res)=>{
    res.sendFile(__dirname+'/item/cursor.gif');
});
app.get('/item/oak_log.png',(req, res)=>{
    res.sendFile(__dirname+'/item/oak_log.png');
});
app.get('/item/oak_planks.png',(req, res)=>{
    res.sendFile(__dirname+'/item/oak_planks.png');
});
app.get('/item/slot.png',(req, res)=>{
    res.sendFile(__dirname+'/item/slot.png');
});
app.get('/item/stick.png',(req, res)=>{
    res.sendFile(__dirname+'/item/stick.png');
});
app.get('/block/diamond_ore.png',(req, res)=>{
    res.sendFile(__dirname+'/block/diamond_ore.png');
});
app.get('/block/emerald_ore.png',(req, res)=>{
    res.sendFile(__dirname+'/block/emerald_ore.png');
});
app.get('/block/lapis_ore.png',(req, res)=>{
    res.sendFile(__dirname+'/block/lapis_ore.png');
});
app.get('/block/iron_ore.png',(req, res)=>{
    res.sendFile(__dirname+'/block/iron_ore.png');
});
app.get('/block/stone.png',(req, res)=>{
    res.sendFile(__dirname+'/block/stone.png');
});
app.get('/signup.html',(req, res)=>{
    res.sendFile(__dirname+'/signup.html');
});
app.get('/login.html',(req, res)=>{
    res.sendFile(__dirname+'/login.html');
});
app.get('/static/signup.png',(req, res)=>{
    res.sendFile(__dirname+'/static/signup.png');
});
app.get('/static/login.png',(req, res)=>{
    res.sendFile(__dirname+'/static/login.png');
});

app.listen(80);

console.log("Minercon ^1.8 Frontend Server Started (http://localhost:80)[HTTP Header]");