const read=require('fs').readFileSync;
const write=require('fs').writeFileSync;
const path=require('path');
const system=require('child_process').exec;

function FileExists(pth){
    try{
        read(pth);
        return true;
    }catch{
        return false;
    }
}

function runPython(code){
    if(!FileExists('.cache/runpython.py')){
        system("mkdir .cache",()=>{
            write('.cache/runpython.py',code);
        });
    }
    system("python .cache/runpython.py", (error, stdout, stderr) => {
        write('.cache/runpython.py',code);
        if (error) {
            console.log(`${error.message}`);
            return;
        }
        if (stderr) {
            console.log(`StdErr: ${stderr}`);
            return;
        }
        console.log(`${stdout}`)}
    );
}

function runPythonFile(filePath,ErrCallback=()=>{throw "FileNotFound: "+filePath}){
    if(FileExists(filePath)){
        runPython(read(filePath,'utf8'));
    }else{
        ErrCallback();
    }
}


class Window{
    constructor(options={width:800,height:500,title:"ScriptWind"}){
        this.options=options;
    }

    spawn(){
        const elec=`const { app, BrowserWindow ,Menu} = require('electron')
        
        const createWindow = () => {
          // Create the browser window
          const mainWindow = new BrowserWindow({
            width: ${this.options.width},
            height: ${this.options.height},
            title:"${this.options.title.split('"').join('\\"')}",
          })
        
          mainWindow.loadURL('https://google.com');
          mainWindow.setMenu(null);
          // mainWindow.webContents.openDevTools()
        }
        
        app.whenReady().then(() => {
          createWindow()
          app.on('activate', () => {
            // On macOS it's common to re-create a window in the app when the
            // dock icon is clicked and there are no other windows open.
            if (BrowserWindow.getAllWindows().length === 0) createWindow()
          })
        })
        
        // Quit when all windows are closed, except on macOS. There, it's common
        // for applications and their menu bar to stay active until the user quits
        // explicitly with Cmd + Q.
        app.on('window-all-closed', () => {
          if (process.platform !== 'darwin') app.quit()
        })
        
        // In this file you can include the rest of your app's specific main process
        // code. You can also put them in 
        `;
        if(!FileExists('.cache/window.js')){
            system("mkdir .cache",()=>{
                write('.cache/window.js',elec);
            });
        }
        write('.cache/window.js',elec);
        system('electron .cache/window.js');
    }
    
    Text(text="", css={}, attr={}){
        let z=document.createElement('h4');
        z.innerText=text;
        let keys=Object.keys(css);
        for(let i=0;i<keys;i++){
            z.style[keys[i]]=css[keys[i]];
        }
        keys=Object.keys(attr);
        for(let i=0;i<keys;i++){
            z[keys[i]]=attr[keys[i]];
        }
    }
}

module.exports={
    runPython,
    runPythonFile,
    Window
}