const Server=require('ws').Server;
const read=require('fs').readFileSync;
const write=require('fs').writeFileSync;
const wss=new Server({port:5000});
const base=JSON.parse(read('base.json','utf8'));

const CryptoJS=require('crypto-js');
var keySize = 256;
var ivSize = 128;
var iterations = 100;


function encrypt (msg, pass) {
  var salt = CryptoJS.lib.WordArray.random(128/8);
  
  var key = CryptoJS.PBKDF2(pass, salt, {
      keySize: keySize/32,
      iterations: iterations
    });

  var iv = CryptoJS.lib.WordArray.random(128/8);
  
  var encrypted = CryptoJS.AES.encrypt(msg, key, { 
    iv: iv, 
    padding: CryptoJS.pad.Pkcs7,
    mode: CryptoJS.mode.CBC
    
  });
  
  // salt, iv will be hex 32 in length
  // append them to the ciphertext for use  in decryption
  var transitmessage = salt.toString()+ iv.toString() + encrypted.toString();
  return transitmessage;
}

function decrypt (transitmessage, pass) {
  var salt = CryptoJS.enc.Hex.parse(transitmessage.substr(0, 32));
  var iv = CryptoJS.enc.Hex.parse(transitmessage.substr(32, 32))
  var encrypted = transitmessage.substring(64);
  
  var key = CryptoJS.PBKDF2(pass, salt, {
      keySize: keySize/32,
      iterations: iterations
    });

  var decrypted = CryptoJS.AES.decrypt(encrypted, key, { 
    iv: iv, 
    padding: CryptoJS.pad.Pkcs7,
    mode: CryptoJS.mode.CBC
    
  })
  return decrypted.toString(CryptoJS.enc.Utf8);
}

function range(x){
    let arr=[];
    for(let i=0;i<x;i++)arr.push(i);
    return arr;
}

wss.on('connection',e=>{
    e.on('message',dt=>{
        dt=JSON.parse(dt.toString());
        if(dt.type=="create"){
            let fnd=false;

            for(let i of base.users){
                if(i.email==dt.email){
                    console.log(dt.email+" Already Exists");
                    fnd=true;
                    e.send(JSON.stringify({
                        type:"create:f",
                        msg:"Account with that Email Already Exists"
                    }));
                    break;
                }
            }

            if(!fnd){
                base.users.push({
                    email:dt.email,
                    name:dt.name,
                    p:dt.p,
                    money:50,
                    pickowned:"wooden",
                    pick:"miner:wooden_pickaxe"
                });
                write('base.json',JSON.stringify(base, undefined, 4));
                console.log("Created a new account for "+dt.email);
                e.send(JSON.stringify({
                    type:"create:t",
                    msg:"Account Created!",
                    cookie: encrypt(dt.p, dt.email)
                }));
            }
        }
        if(dt.type=="connect"){
            let fnd=false;

            for(let i of base.users){
                if(i.email==dt.email){
                    fnd=true;
                    if(i.p==dt.p){
                        console.log(dt.email+" Have Logged-in To Account");
                        e.send(JSON.stringify({
                            type:"connect:t",
                            cookie: encrypt(dt.p, dt.email)
                        }));
                    }else{
                        console.log(dt.email+" Has entered wrong password");
                        e.send(JSON.stringify({
                            type:"connect:f",
                            msg:"Wrong Password",
                        }));
                    }
                    break;
                }
            }

            if(!fnd){
                console.log(dt.email+" Doesn't Exists");
                e.send(JSON.stringify({
                    type:"connect:f",
                    msg:"Account Doesn't Exists",
                }));
            }
        }

        if(dt.type=="fetch"){
            let _=decrypt(dt.cookie, dt.email);
            let fnd=false;
            for(let i of base.users){
                if(i.p==_){
                    fnd=true;
                    e.send(JSON.stringify({
                        type:"fetch:t",
                        money:i.money,
                        pickowned:i.pickowned,
                        pick:i.pick
                    }));
                }
            }
            if(!fnd){
                e.send(JSON.stringify({
                    type:"fetch:f",
                    msg:"Error Authentication of your account"
                }));
            }
        }
        if(dt.type=="post"){
            let _=decrypt(dt.cookie, dt.email);
            let f_nd=false;
            for(let i=0;i<base.users.length;i++){
                if(base.users[i].p==_){
                    f_nd=true;
                    base.users[i].money=dt.money;
                    base.users[i].pickowned=dt.pickowned;
                    base.users[i].pick=dt.pick;
                    write('base.json', JSON.stringify(base, undefined, 4));
                    e.send(JSON.stringify({
                        type:"post:t",
                    }));
                    break;
                }
            }
            if(!f_nd){
                e.send(JSON.stringify({
                    type:"post:f",
                    msg:"Error Authentication of your account, Please Logout and Login again"
                }));
            }
        }
    });
});

console.log("Database Server Started (http://localhost:8000)[HTTP Header]");