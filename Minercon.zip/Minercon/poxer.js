/**
 * @license (MIT)
 * Copyright 2022 Poxer.js Author (PoopyLulu, UtkMcpe78)[https://replit.com/@LuluAwesomeReplers]
 */


// Poxer class
// Code example:
/*
    const poxer=new Poxer(500, 500, ["backgroundColor=black", "border=1px solid white"]);
*/

class Poxer{
    constructor(width, height, styles=[]){
        // Setting up everything
        this.canvas=document.createElement('canvas');
        this.context=this.canvas.getContext('2d');
        this.canvas.height=height;
        this.canvas.width=width;
        this.W=width;
        this.H=height;
        // parsing styles e.g. parameter: ["backgroundColor=black", "border=1px solid white"]
        for(let i=0;i<styles.length;i++){
            this.canvas.style[styles[i].split('=')[0]]=styles[i].split('=')[1];
        }
        // Adding canvas to DOM
        document.body.appendChild(this.canvas);
        // Mouse and keyboard input
        this._={};
        this.Mouse={x:this.W/2, y:this.H/2, AccX:0, AccY:0, held:false};
        addEventListener('keydown', e=>this._[e.code]=true);
        addEventListener('keyup', e=>this._[e.code]=false);
        addEventListener('mousemove', e=>{
            this.Mouse.x=e.clientX-this.canvas.offsetLeft;
            this.Mouse.y=e.clientY-this.canvas.offsetTop;
            this.Mouse.AccX=e.movementX;
            this.Mouse.AccY=e.movementY;
        });
        let oldaccX=this.Mouse.AccX;
        let oldaccY=this.Mouse.AccY;
        setInterval(()=>{
            if(oldaccX==this.Mouse.AccX)this.Mouse.AccX=0;
            if(oldaccY==this.Mouse.AccY)this.Mouse.AccY=0;
            oldaccX=this.Mouse.AccX;
            oldaccY=this.Mouse.AccY;
        },10);
        addEventListener('mousedown', e=>this.Mouse.held=true);
        addEventListener('mouseup', e=>this.Mouse.held=false);
        // Setup done
        console.log("Poxer Loaded Successfully");
    }

    CreateBox(x, y, w, h, fill, options=[]){
        // Creates a box object and return it
        // In 5th parameter use "F" for fill mode, "S" for stroke mode and "B" for both
        // Code example
        /*
            const box=poxer.CreateBox(50, 50, 100, 100, 'F', ["fillStyle=green"]);
        */
        return {
            type:"Rectangle",
            x, y, w, h, fill,
            options
        }
    }
    ForLoop(istart, callback){
        // An Alternative of build-in For-Loop
        // Bcz this loop is Asyncronous and runs in background
        // syntax of you want to render a list with this loop
        /*
            const poxer=new Poxer(500, 500);
            const objects=[...];
            poxer.ForLoop(0, (i, inc)=>{
                if(i==objects.length)return true;
                poxer.Render(objects[i]);
                inc(i+1);
            });
        */
        let isdoneyet=false;
        let n=setInterval(()=>{
            let close=callback(istart, (ni)=>{
                istart=ni;
            });
            if(close){
                this.KillForLoop(n);
                isdoneyet=true;
            }
        });
        return isdoneyet;
    }

    // Kills A Poxer.ForLoop (Only for Poxer use)
    KillForLoop(n){clearInterval(n)}

    // Clear outs all pixels in the screen
    Refresh(){
        this.context.clearRect(-2000, -2000, 4000, 4000);
    }

    // Runs a CTX function code Example:
    /*
        const poxer=new Poxer(500, 500);
        poxer.RunFunction('fillRect', [0,0, 50, 50]);
    */
    RunFunction(fname, args=[]){
        this.context[fname](...args);
    }

    // Renders a Poxer Object code Example:
    /*
        const box=poxer.CreateBox(50, 50, 100, 100, 'F', ["fillStyle=green"]);
        poxer.Render(box);
    */
    Render(id){
        this.context.beginPath();
        let st=id;
        for(let i=0;i<st.options.length;i++){
            this.context[st.options[i].split('=')[0]]=st.options[i].split('=')[1];
        }
        if(st.type=="Rectangle"){
            if(st.fill=='F')this.context.fillRect(st.x, st.y, st.w, st.h);
            else if(st.fill=='S'){
                this.context.rect(st.x, st.y, st.w, st.h);
                this.context.stroke();
            }
            else if(st.fill=='B'){
                this.context.fillRect(st.x, st.y, st.w, st.h);
                this.context.rect(st.x, st.y, st.w, st.h);
                this.context.stroke();
            }
        }
        if(st.type=="Text"){
            if(st.fill=='F')this.context.fillText(st.str, st.x, st.y, st.w);
            else if(st.fill=='S'){
                this.context.strokeText(st.str, st.x, st.y, st.w);
                this.context.stroke();
            }
            else if(st.fill=='B'){
                this.context.fillText(st.str, st.x, st.y, st.w);
                this.context.strokeText(st.str, st.x, st.y, st.w);
                this.context.stroke();
            }
        }
        if(st.type=="Arc"){
            if(st.fill=='F'){
                this.context.arc(st.x, st.y, st.r, st.start, st.end, false);
                this.context.fill();
            }
            else if(st.fill=='S'){
                this.context.arc(st.x, st.y, st.r, st.start, st.end, false);
                this.context.stroke();
            }
            else if(st.fill=='B'){
                this.context.arc(st.x, st.y, st.r, st.start, st.end, false);
                this.context.stroke();
                this.context.arc(st.x, st.y, st.r, st.start, st.end, false);
                this.context.fill();
            }
        }
        if(st.type=="Lines"){
            if(st.fill=='F'){
                const ln=st.lines[0];
                this.context.moveTo(ln[0], ln[1]);
                for(let i=1;i<st.lines.length;i++){
                    const ln=st.lines[i];
                    try{
                        this.context.lineTo(ln[0], ln[1]);
                    }catch{}
                }
                this.context.fill();
            }
            else if(st.fill=='S'){
                const ln=st.lines[0];
                this.context.moveTo(ln[0], ln[1]);
                for(let i=1;i<st.lines.length;i++){
                    const ln=st.lines[i];
                    this.context.lineTo(ln[0], ln[1]);
                }
                this.context.stroke();
            }
            else if(st.fill=='B'){
                const ln=st.lines[0];
                this.context.moveTo(ln[0], ln[1]);
                for(let i=1;i<st.lines.length;i++){
                    const ln=st.lines[i];
                    this.context.lineTo(ln[0], ln[1]);
                }
                this.context.fill();
                this.context.stroke();
            }
        }
        if(st.type=="Image"){
            if(st.wait){
                st.img.onload=()=>{
                    this.context.drawImage(st.img, st.x, st.y, st.w, st.h);
                }
            }else{
                this.context.drawImage(st.img, st.x, st.y, st.w, st.h);
            }
        }
        // if(st.type=="GoTo"){
        //     this.context.moveTo(st.x, st.y);
        // }
        if(st.type=="StrokeTo"){
            this.context.moveTo(st.x, st.y);
            this.context.lineTo(st.x2, st.y2);
            this.context.stroke();
        }
        this.context.closePath();
    }


    // Rotate An Object with origin as object.x,object.y or object.x1, object.y1 or object.lines[0][0],object.lines[0][1]

    // Code Example
    /*
        const myRect=poxer.CreateBox(...);
        poxer.Rotate(myRect, .5, ()=>{
            poxer.Render(myRect);
        });
    */

    Rotate(id,deg,betweenCall){
        if(id.type=="Lines"){
            this.context.save();
            this.context.translate(id.lines[0][0],id.lines[0][1]);
            this.context.rotate(deg);
            this.context.translate(-id.lines[0][0],-id.lines[0][1]);
            betweenCall();
            this.context.restore();
        }else if(id.type=='StrokeTo'){
            this.context.save();
            this.context.translate(id.x1,id.y1);
            this.context.rotate(deg);
            this.context.translate(-id.x1,-id.y1);
            betweenCall();
            this.context.restore();
        }else{
            this.context.save();
            this.context.translate(id.x,id.y);
            this.context.rotate(deg);
            this.context.translate(-id.x,-id.y);
            betweenCall();
            this.context.restore();
        }
    }


    // Rotate An Object with given Origin (x,y)

    // Code Example
    /*
        const myRect=poxer.CreateBox(...);
        poxer.Rotate(myRect, .5, 200, 200,()=>{
            poxer.Render(myRect);
        });
    */

    RotateAbs(id,deg,x,y,betweenCall){
        if(id.type=="Lines"){
            this.context.save();
            this.context.translate(x,y);
            this.context.rotate(deg);
            this.context.translate(-x,-y);
            betweenCall();
            this.context.restore();
        }else if(id.type=='StrokeTo'){
            this.context.save();
            this.context.translate(x,y);
            this.context.rotate(deg);
            this.context.translate(-x,-y);
            betweenCall();
            this.context.restore();
        }else{
            this.context.save();
            this.context.translate(x,y);
            this.context.rotate(deg);
            this.context.translate(-x,-y);
            betweenCall();
            this.context.restore();
        }
    }
    // Creates a text
    // Code example
    /*
        const text=poxer.CreateText("This is a text", 50, 50, 100, "F", [font="30px cursive"]);
    */
    CreateText(str, x, y, w, fill, options=[]){
        return{
            type:"Text",
            x, y, w, str,fill,
            options
        }
    }

    // Creates a Loop (Usefull for games)
    // code Example
    /*
        let FPS=60 // Frames Per Second (more FPS = more faster Loop)
        poxer.CreateLoop(()=>{
            // Your Code
        }, FPS);
    */

    CreateLoop(Callback, fps=120){
        return setInterval(()=>{
            Callback()
        }, 1000/fps);
    }
    
    // Kills a Poxer Loop
    // Code example
    /*
        const myLoop=poxe.CreateLoop(...);
        poxer.KillLoop(myLoop);
    */
    KillLoop(LoopId){
        clearInterval(LoopId);
    }

    // Function to Detect Collision Between Two Rectangles 
    // Code example
    /*
        let bool=poxer.Overlaps(box1, box2);
    */
    Overlaps(rect1, rect2){
        if (rect1.x < rect2.x + rect2.w &&
            rect1.x + rect1.w > rect2.x &&
            rect1.y < rect2.y + rect2.h &&
            rect1.h + rect1.y > rect2.y)return true;
            return false
    }

    // Creates a linear Arc
    // Code example
    /*
        let arc=poxer.CreateLinearArc(50, 50, 30, 180, 0, 'F', ["fillStyle=red"]);
    */

    CreateLinearArc(x, y, r, start, end, fill, options=[]){
        return {
            type:"Arc",
            x, y, r, start, end,
            fill, options
        }
    }

    // Creates a Circle
    // Code example
    /*
        let circle=poxer.CreateCirle(50, 50, 30, 'F', ["fillStyle=red"]);
    */

    CreateCircle(x, y, r, fill, options=[]){
        return {
            type:"Arc",
            x, y, r, start:0, end:360,
            fill, options
        }
    }

    // Creates a Custom Shape
    // Code example
    /*
        // Creating Vertex of a Triangle
        let lines=[
            [50, 50],
            [100, 100],
            [0, 100],
            [50, 50],
        ];

        const triangle=poxer.CreatePolygon(lines, "F", ["fillStyle=white"]);
        poxer.Render(triangle);
    */

    CreatePolygon(lines=[], fill, options=[]){
        return {
            type:"Lines",
            lines, fill, options
        }
    }

    // !NOTE! ImageConfig is now depricated and wont be supported, use loadimage function instead! 

    ImageConfig(src, x, y, w, h){
        console.error("Depricated: Poxer.ImagConfig is now depricated and not supported at ALL!\nNow you can just enter the url and and other params in Poxer.LoadImage()")
        return {
            type:"DEPRICATED!", w, h, x, y,
            src, data:"DEPRICATED"
        }
    }

    // Loads and Returns Image, Takes Image config Data to load Image
    // Code example
    /*
        const image=poxer.LoadImage("path/to/your/image.png", 30, 30, 50, 50, true);
        // Last argument is for wait till the image loads, setting it true will make image render on screen after its loaded
        but setting it to false will make it render the image no matter if its loaded or not
        (Set it to false if you are rendering an image in an asyncronous loop)
        poxer.Render(image);
    */
    LoadImage(src, x, y, w, h, wait=true){
        const img=new Image();
        img.src=src;
        return {
            type:"Image",
            src:src, img, x:x, y:y, w:w, h:h, options:[], wait
        }
    }

    // Creates Line from x, y to x2, y2
    // Code example
    /*
        const line=poxer.StrokeTo(10, 10, 50, 50, ["strokeStyle=blue"]);
        poxer.Render(line);
    */
    
    StrokeTo(x, y, x2, y2, options=[]){
        return {
            type:"StrokeTo",
            x, y, x2, y2, options
        }
    }

    // Changes A Property of Poxer.Context 
    // Code example
    /*
        poxer.SetCtx("lineWidth", 5);
    */
    SetProperty(pname, pvalue){
        this.context[pname]=pvalue;
    }

    RenderThese(arr){
        for(let i of arr){
            this.Render(i);
        }
    }
}