function setCookie(cname, cvalue, exdays) {
    const d=new Date();
    d.setTime(d.getTime()+(exdays*24*60*60*1000));
    let expires="expires="+d.toUTCString();
    document.cookie=cname+"="+cvalue+";"+expires+";path=/";
}
function getCookie(cname) {
    let name=cname+"=";
    let decodedCookie=decodeURIComponent(document.cookie);
    let ca=decodedCookie.split(';');
    for(let i=0;i<ca.length;i++) {
    let c=ca[i];
    while (c.charAt(0)==' ') {
        c=c.substring(1);
    }
    if (c.indexOf(name)==0) {
        return c.substring(name.length, c.length);
    }
    }
    return "";
}

function userFetch(){
    const ws=new WebSocket('wss://minerserver.luluawesomereplers.repl.co');
    ws.addEventListener('open',e=>{
        ws.send(JSON.stringify({
            type:"fetch",
            email:getCookie('email'),
            cookie:getCookie('_user_acc')
        }));
    })
    ws.addEventListener('message',e=>{
        let _=JSON.parse(e.data);
        if(_.type=="fetch:t"){
            setCookie('_pickmoney',_.money);
            setCookie('_pickowned',_.pickowned);
            setCookie('pick',_.pick);
        }else if(_.type=="fetch:f"){
            this.location.href="/login.html?auth?"+x+'?'+y
        }
    });
}

function post(cb=()=>{}){
    const ws=new WebSocket('wss://minerserver.luluawesomereplers.repl.co');
    ws.addEventListener('open',e=>{
        ws.send(JSON.stringify({
            type:"post",
            money:getCookie('_pickmoney'),
            pickowned:getCookie('_pickowned'),
            pick:getCookie('pick'),
            email:getCookie('email'),
            cookie:getCookie('_user_acc')
        }));
    })
    ws.addEventListener('message',e=>{
        let _=JSON.parse(e.data);
        cb();
        if(_.type=="post:f"){
            this.location.href="/login.html?auth?"+x+'?'+y
        }
    });
}

let _setx=location.href.split('/')[3].split('?')[2];
let _sety=location.href.split('/')[3].split('?')[3];
let _tin=location.href.split('/')[3].split('?')[1];
if(_tin=="auth")alert("Error Authentication of your account, Please Log-in Again");

let money=getCookie('_pickmoney');
if(!money){setCookie('_pickmoney','50',9999);money="50"}

let __cs=document.createElement('img');
__cs.src="item/cursor.gif";
__cs.width=50;
__cs.style.position='absolute';
__cs.style.left=(_setx?_setx:0)+'px';
__cs.style.top=(_sety?_sety:0)+'px';
__cs.style.transform="rotateY(180deg)";
__cs.style.transform="rotateZ(-90deg)";
__cs.draggable=false;
__cs.style.userSelect='none';
document.body.style.setProperty('cursor','none',"important");
document.body.style.overflow="hidden";
document.getElementsByTagName('html')[0].style.cursor="none";
// document.getElementsByTagName('html')[0].style.overflow="hidden";

var scrollLeft = (window.pageXOffset !== undefined) ? window.pageXOffset : (document.documentElement || document.body.parentNode || document.body).scrollLeft;
var scrollTop = (window.pageYOffset !== undefined) ? window.pageYOffset : (document.documentElement || document.body.parentNode || document.body).scrollTop;
let x=(_setx?_setx:0);
let y=(_sety?_sety:0);

if(location.href.split('/')[3].split('?')[0]!='signup.html'&&location.href.split('/')[3].split('?')[0]!='login.html'){
    let acc=getCookie('_user_acc');
    if(!acc){this.location.href="/login.html?null?"+x+'?'+y}
}
if(location.href.split('/')[3].split('?')[0]=='try.html'){
    setInterval(()=>{
        post();
    },1000);
}

addEventListener('mousemove',e=>{
    x=(e.clientX+scrollLeft)+5;
    y=(e.clientY+scrollTop)+5;
    // x+=e.movementX;
    // y+=e.movementy;
});
setInterval(()=>{
    scrollLeft = (window.pageXOffset !== undefined) ? window.pageXOffset : (document.documentElement || document.body.parentNode || document.body).scrollLeft;
    scrollTop = (window.pageYOffset !== undefined) ? window.pageYOffset : (document.documentElement || document.body.parentNode || document.body).scrollTop;
    __cs.style.left=x+'px';
    __cs.style.top=y+'px';
});

document.body.appendChild(__cs);

addEventListener('contextmenu',e=>{
    e.preventDefault();
});

let _ips=document.getElementsByTagName('input');

for(let i of _ips){
    i.addEventListener('mouseenter',e=>{
        __cs.style.transform="rotateZ(-45deg)";
    });
    i.addEventListener('mouseout',e=>{
        __cs.style.transform="rotateZ(-90deg)";
    });
    i.addEventListener('change',e=>{
        if(i.type=='email'){
            t=i.value.split(' ').join('');
            i.value=t;
        }
    });
}

let _allEls=document.body.children;

for(let i of _allEls){
    i.style.setProperty('cursor', "none", "important");
}