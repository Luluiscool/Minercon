let pick=getCookie('pick');
if(!pick){setCookie('pick', "miner:wooden_pickaxe", 9999);pick="miner:wooden_pickaxe"}

// Creating a new canvas Context (Used own made poxer.js library)
const cx=new Poxer(innerWidth,innerHeight);
cx.context.imageSmoothingEnabled=true;
cx.context.imageSmoothingQuality="high";
let canmove=false;


// Inventory class
class Inventory{
    constructor(maxSlots=9, w=500, items=[]){
        this.w=w;
        this.h=w/maxSlots;
        this.maxSlots=maxSlots;
        this.item=items;
        this.hotbarStarts=(cx.W/2)-(this.w/2);
        this.hotbarEnds=cx.H-(this.h*1.2);
        this.hold=0;
    }

    // Renders the inventory hotbar
    render(){
        cx.Render(cx.CreateBox(this.hotbarStarts, this.hotbarEnds, this.w, this.h, "S", ['strokeStyle=black','lineWidth=3']));
        for(let i of range(this.maxSlots)){
            cx.Render(cx.CreateBox(this.hotbarStarts+(i*this.h), this.hotbarEnds, this.h, this.h, 'S', ['strokeStyle=black','lineWidth=3']));
        }

        for(let i of range(this.item.length)){
            cx.context.drawImage(this.item[i].display, this.hotbarStarts+(i*this.h), this.hotbarEnds, this.h, this.h);
            cx.SetProperty('font', "23px monospace");
            cx.SetProperty('fillStyle','white');
            cx.context.fillText(this.item[i].count>1?this.item[i].count:"", this.hotbarStarts+(i*this.h)+5, this.hotbarEnds+this.h-3, 100);
        }

        cx.Render(cx.CreateBox(this.hotbarStarts+(this.hold*this.h), this.hotbarEnds, this.h, this.h, 'S', ['strokeStyle=white','lineWidth=4']));
    }

    // Opens player's inventory
    open(){
        if(canmove)canmove=false;
        else canmove=true;
        return;
    }
}


const minerconSource={
    "miner:wooden_pickaxe":"pickaxe/wooden.png",
    "miner:iron_pickaxe":"pickaxe/iron.png",
    "miner:stone_pickaxe":"pickaxe/stone.png",
    "miner:diamond_pickaxe":"pickaxe/diamond.png",
    "miner:stone":"block/stone.png",
    "block:cobblestone":"item/cobblestone.png",
    "item:diamond":"item/diamond.png",
    "item:emerald":"item/emerald.png",
    "item:lapis":"item/lapis.png",
    "item:iron":"item/iron.png",
    // "block:oak_log":"item/oak_log.png",
    // "block:oak_planks":"item/oak_planks.png",
    // "item:stick":"item/stick.png",
}

// Inventory instance
const inv=new Inventory(9,500,InvokeInventoryUpdate([
    {id:pick, src:minerconSource[pick], count:1, stack:1},
]));

// GLobals and Functions
const gridSize=50;
let locked=undefined;
let swipe=false;

const ores={
    diamond:"block/diamond_ore.png",
    lapis:"block/lapis_ore.png",
    iron:"block/iron_ore.png",
    emerald:"block/emerald_ore.png",
    stone:"block/stone.png",
};
const pickaxe={
    wooden:true,
    stone:false,
    iron:false,
    diamond:false,
}



function fit(x){
    return Math.floor(x/gridSize)*gridSize;
}
function ReRender(){
    cx.Refresh();
    for(let i of done){
        // console.log(i);
        cx.context.drawImage(i[0],i[1],i[2],i[3],i[3]);
    }
    inv.render();
}
function range(x){
    let arr=[];
    for(let i=0;i<x;i++)arr.push(i);
    return arr;
}
function InvokeInventoryUpdate(items=[]){
    let arr=[];
    for(let i of items){
        let img=new Image();
        img.src=i.src;
        arr.push({id:i.id, display:img, count:i.count, stack:i.stack});
    }
    return arr;
}
function FindArrayLength(arr){
    for(let i=0;i<Infinity;i++){
        if(!arr[i])return i;
    }
}
function NBT(nbt){
    return {id:nbt.id, display:nbt.display, count:nbt.count, stack:nbt.stack};
}
function CollectInventoryItem(nbt){
    let hasAlr=false;
    for(let i=0;i<inv.item.length;i++){
        let it=inv.item[i];
        if(inv.item[i].id==nbt.id&&inv.item[i].count<inv.item[i].stack){
            hasAlr=true;
            if(it.stack-it.count>=nbt.count){
                inv.item[i].count+=nbt.count;
                break;
            }
            else if(nbt.count>=nbt.stack&&it.stack>it.count){
                // alert();
                let temp=inv.item[i].count;
                inv.item[i].count=nbt.stack;
                nbt.count=temp/2;

                CollectInventoryItem(nbt);
            }
            else{
                nbt.count-=it.stack-it.count;
                inv.item[i].count=it.stack;
                CollectInventoryItem(nbt);
            }
        }
    }
    if(!hasAlr){
        inv.item.push(InvokeInventoryUpdate([
            {id:nbt.id, src:minerconSource[nbt.id], count:nbt.count, stack:nbt.stack}
        ])[0]);
    }
}

function SetNewOreAt(x,y){
    let r=Math.random();
    if(r<.25){
        return cx.CreateBox(x,y,gridSize,gridSize,'F',['fillStyle=lime']);
    }
    else if(r<.5){
        return cx.CreateBox(x,y,gridSize,gridSize,'F',['fillStyle=red']);
    }
    else if(r<.75){
        return cx.CreateBox(x,y,gridSize,gridSize,'F',['fillStyle=white']);
    }
    else{
        return cx.CreateBox(x,y,gridSize,gridSize,'F',['fillStyle=cyan']);
    }
}

function GenerateCave(xLimit, yLimit, blockSize){
    let arr=[];
    for(let x=0;x<xLimit;x++){
        for(let y=0;y<yLimit;y++){
            let r=Math.random();
            if(r<.02){
                let img=new Image();
                img.src=ores.diamond;
                arr.push([img,x*blockSize,y*blockSize,blockSize]);
            }
            else if(r<.05){
                let img=new Image();
                img.src=ores.emerald;
                arr.push([img,x*blockSize,y*blockSize,blockSize]);
            }
            else if(r<.1){
                let img=new Image();
                img.src=ores.lapis;
                arr.push([img,x*blockSize,y*blockSize,blockSize]);
            }
            else if(r<.15){
                let img=new Image();
                img.src=ores.iron;
                arr.push([img,x*blockSize,y*blockSize,blockSize]);
            }
            else{
                let img=new Image();
                img.src=ores.stone;
                arr.push([img,x*blockSize,y*blockSize,blockSize]);
            }
        }
    }
    return arr;
}
function pauseGame(){
    location.href="/?null?"+x+'?'+y;
}

let ind=0;
setInterval(()=>{
    
});

// Player and other variables
let miner=cx.CreateBox(fit(cx.W/2),fit(cx.H/2),gridSize,gridSize,'F',['fillStyle=skyblue']);
let done=GenerateCave(cx.W/gridSize,cx.H/gridSize,gridSize);
let quick=true

// Loading ores once
for(let i of done){
    cx.Refresh();
    cx.context.drawImage(i[0],i[1],i[2],i[3],i[3]);
}

// Render Result recipe item

// Game Loop
setInterval(()=>{
    // Rendering Stuff
    try{
        let curobj=cx.CreateBox(cx.Mouse.x,cx.Mouse.y,1,1,'S');
        for(let i of range(inv.maxSlots)){
            let itemobj=cx.CreateBox(inv.hotbarStarts+(i*inv.h), inv.hotbarEnds, inv.h, inv.h);
            if(cx.Overlaps(curobj,itemobj)&&cx.Mouse.held&&!cx._.ControlLeft){
                if(locked==undefined||locked==null){
                    locked=inv.item[i];
                    inv.item.splice(i,1);
                    ReRender();
                    cx.Mouse.held=false;
                    break;
                }else{
                    let temp=locked;
                    if(inv.item[i]==undefined){
                        locked=undefined;
                        inv.item.push(temp);
                    }else if(inv.item[i].id!=temp.id){
                        locked=inv.item[i];
                        inv.item[i]=temp;
                    }else{
                        if(inv.item[i].count+locked.count>inv.item[i].stack){
                            locked.count-=inv.item[i].stack-inv.item[i].count;
                            inv.item[i].count=inv.item[i].stack;
                            if(locked.count<1)locked=undefined;
                        }else{
                            CollectInventoryItem(locked);
                            locked=undefined;
                        }
                    }

                    ReRender();
                    cx.Mouse.held=false;
                    break;
                }
            }else if(cx.Overlaps(curobj,itemobj)&&cx.Mouse.held&&cx._.ControlLeft){
                if((locked==undefined||locked==null)&&inv.item[i].count>1){
                    let _=inv.item[i];
                    locked={id:_.id, display:_.display, count:_.count, stack:_.stack};

                    if(_.count%2==0){
                        locked.count/=2;
                        inv.item[i].count/=2;
                    }else{
                        locked.count=(locked.count/2)-.5;
                        inv.item[i].count=(inv.item[i].count/2)+.5;
                    }
                    ReRender();
                    cx.Mouse.held=false;
                    cx._.ControlLeft=false;
                    break;
                }else if(inv.item[i].count<inv.item[i].stack&&inv.item[i]!=undefined){
                    if(locked.count>0){
                        inv.item[i].count++;
                        locked.count--;
                        cx.Mouse.held=false;
                        if(locked.count<=0){
                            locked=undefined;
                        }
                    }else{
                        locked=undefined;
                    }
                    ReRender();
                }
            }
        }
    }catch{
        // Player trying to hold empty slot
    }

    if(locked!=undefined&&locked!=null){
        ReRender();
        canmove?1:cx.Render(miner);
        cx.context.drawImage(locked.display, cx.Mouse.x-(inv.h/2), cx.Mouse.y-(inv.h/2), inv.h, inv.h);
        cx.SetProperty('fillStyle','white');
        cx.context.fillText(locked.count>1?locked.count:"", (cx.Mouse.x-(inv.h/2))+5, (cx.Mouse.y+(inv.h/2))-3, 100);
    }else{
        canmove?1:cx.Render(miner);
    }
},10);

let FIRSTLOOP=0;
let _FART=setInterval(()=>{
    ReRender();
    if(!canmove)cx.Render(miner);
    cx.Render(miner);
    for(let i of done){
        // console.log(i);
        cx.context.drawImage(i[0],i[1],i[2],i[3],i[3]);
    }
    inv.render();
    FIRSTLOOP++;
    if(FIRSTLOOP>50)clearInterval(_FART);
});
// Keyup listener so that use has to press keys instead of holding it
addEventListener('keyup',e=>{
    // Grabbing current position of player before he moves
    const ox=miner.x;
    const oy=miner.y;

    // Rending ores and inventory only when player moves
    cx.Refresh();
    for(let i of done){
        // console.log(i);
        cx.context.drawImage(i[0],i[1],i[2],i[3],i[3]);
    }
    inv.render();
    if(e.code=="KeyE"){
        // inv.open();
        return;
    }
    if(canmove)return;

    // Arrow keys and WASD controls
    if(e.code=="ArrowRight"||e.code=="KeyD")miner.x+=gridSize;
    if(e.code=="ArrowLeft"||e.code=="KeyA")miner.x-=gridSize;
    if(e.code=="ArrowDown"||e.code=="KeyS")miner.y+=gridSize;
    if(e.code=="ArrowUp"||e.code=="KeyW")miner.y-=gridSize;
    if(e.code=="Escape"||e.code=="AltLeft"){
        e.preventDefault();
        pauseGame();
    }

    // Uncommenting these 4 lines of code will make the game.. WORSE!
    /* done.push(SetNewOreAt(miner.x-gridSize,miner.y));
       done.push(SetNewOreAt(miner.x+gridSize,miner.y));
       done.push(SetNewOreAt(miner.x,miner.y+gridSize));
       done.push(SetNewOreAt(miner.x,miner.y-gridSize));
    */

    // Removing block/ore when player goes in that direction
    
    for(let i=0;i<done.length;i++){
        ThisOre=done[i][0].src.split('/')[done[i][0].src.split('/').length-2]+"/"+done[i][0].src.split('/')[done[i][0].src.split('/').length-1];
        if(cx.Overlaps(miner,{x:done[i][1],y:done[i][2],h:done[i][3],w:done[i][3]})){
            try{
                if(ThisOre==ores.diamond&&(inv.item[inv.hold].id=="miner:iron_pickaxe"||inv.item[inv.hold].id=="miner:diamond_pickaxe")){
                    done.splice(i,1);
                    CollectInventoryItem({id:"item:diamond", count:1, stack:64});
                    money=Number(money)+12;
                    setCookie('_pickmoney',money.toString(),9999);
                }else if(ThisOre==ores.diamond){
                    miner.x=ox;
                    miner.y=oy;
                }
                if(ThisOre==ores.emerald&&(inv.item[inv.hold].id=="miner:iron_pickaxe"||inv.item[inv.hold].id=="miner:diamond_pickaxe")){
                    done.splice(i,1);
                    CollectInventoryItem({id:"item:emerald", count:1, stack:64});
                    money=Number(money)+10;
                    setCookie('_pickmoney',money.toString(),9999);
                }else if(ThisOre==ores.emerald){
                    miner.x=ox;
                    miner.y=oy;
                }
                if(ThisOre==ores.lapis&&(inv.item[inv.hold].id=="miner:stone_pickaxe"||inv.item[inv.hold].id=="miner:iron_pickaxe"||inv.item[inv.hold].id=="miner:diamond_pickaxe")){
                    done.splice(i,1);
                    CollectInventoryItem({id:"item:lapis", count:1, stack:64});
                    money=Number(money)+7;
                    setCookie('_pickmoney',money.toString(),9999);
                }else if(ThisOre==ores.lapis){
                    miner.x=ox;
                    miner.y=oy;
                }
                if(ThisOre==ores.iron&&(inv.item[inv.hold].id=="miner:stone_pickaxe"||inv.item[inv.hold].id=="miner:iron_pickaxe"||inv.item[inv.hold].id=="miner:diamond_pickaxe")){
                    done.splice(i,1);
                    CollectInventoryItem({id:"item:iron", count:1, stack:64});
                    money=Number(money)+4;
                    setCookie('_pickmoney',money.toString(),9999);
                }else if(ThisOre==ores.iron){
                    miner.x=ox;
                    miner.y=oy;
                }
                if(ThisOre==ores.stone&&(inv.item[inv.hold].id=="miner:wooden_pickaxe"||inv.item[inv.hold].id=="miner:stone_pickaxe"||inv.item[inv.hold].id=="miner:iron_pickaxe"||inv.item[inv.hold].id=="miner:diamond_pickaxe")){
                    done.splice(i,1);
                    CollectInventoryItem({id:"block:cobblestone", count:1, stack:64});
                    money=Number(money)+2;
                    setCookie('_pickmoney',money.toString(),9999);
                }else if(ThisOre==ores.stone){
                    miner.x=ox;
                    miner.y=oy;
                }
            }catch{
                // Error means user is holding no item in hand
                miner.x=ox;
                miner.y=oy;
            }
        }
    }
});


// Handling Keydown event (Keydown and keyup are both different, Keydown is when user presses down the key and keyup is when user releases the key)
addEventListener('keydown',_=>{
    // Num Keys to select Slot in hotbar
    if(_.code.substr(0, 5)=="Digit")inv.hold=Number(_.code[_.code.length-1])-1;
});