// !FIX! Render glitch! 
// Make That items would show in crafting result
// add log recipes

// Add item+static
// Add cursor.js, game.js, home.html, shop.html